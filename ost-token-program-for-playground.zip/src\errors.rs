// ============================================================================
// Custom Errors for OST Token Program
// ============================================================================

use anchor_lang::prelude::*;

#[error_code]
pub enum OstError {
    #[msg("Confidential transfers must be enabled for this mint")]
    ConfidentialTransfersNotEnabled,

    #[msg("Stake lock period has not elapsed yet")]
    StakeLockNotExpired,

    #[msg("Insufficient staked balance")]
    InsufficientStake,

    #[msg("Voting period for this proposal has ended")]
    VotingPeriodEnded,

    #[msg("Voting period for this proposal has not ended yet")]
    VotingPeriodNotEnded,

    #[msg("User has already voted on this proposal")]
    AlreadyVoted,

    #[msg("Proposal description exceeds maximum length")]
    DescriptionTooLong,

    #[msg("Invalid proof data provided")]
    InvalidProofData,

    #[msg("Tax year must be between 2020 and 2100")]
    InvalidTaxYear,

    #[msg("Unauthorized: only admin can perform this action")]
    Unauthorized,

    #[msg("Amount must be greater than zero")]
    ZeroAmount,

    #[msg("Arithmetic overflow")]
    Overflow,

    #[msg("Proposal has already been executed")]
    ProposalAlreadyExecuted,

    #[msg("Cannot unstake zero amount")]
    NothingToUnstake,

    #[msg("Fee basis points cannot exceed 1000 (10%)")]
    FeeTooHigh,

    #[msg("Merchant label exceeds maximum length")]
    MerchantLabelTooLong,

    #[msg("Merchant account is not active")]
    MerchantNotActive,

    #[msg("DAO treasury not initialized")]
    TreasuryNotInitialized,

    #[msg("Deposit amount exceeds public balance")]
    InsufficientPublicBalance,

    #[msg("Bearer note has already been redeemed")]
    BearerNoteAlreadyRedeemed,

    #[msg("Bearer note has expired")]
    BearerNoteExpired,

    #[msg("Bearer note secret does not match hash")]
    BearerNoteInvalidSecret,

    #[msg("Faucet has already been claimed by this wallet")]
    FaucetAlreadyClaimed,

    #[msg("Invalid DePIN provider code")]
    InvalidProvider,

    #[msg("Invalid resource type code")]
    InvalidResourceType,

    #[msg("Invalid birth year")]
    InvalidBirthYear,

    #[msg("Milestone not yet reached (child too young)")]
    MilestoneNotReached,

    #[msg("This milestone has already been claimed")]
    MilestoneAlreadyClaimed,

    #[msg("Invalid milestone index")]
    InvalidMilestone,

    #[msg("Grow vault has already graduated")]
    VaultAlreadyGraduated,

    #[msg("DePIN stake is not active")]
    DepinNotActive,

    #[msg("DePIN faucet cooldown period active (24h)")]
    DepinCooldownActive,

    #[msg("Duplicate attestation hash — already claimed")]
    DepinDuplicateAttestation,

    #[msg("Invalid quantum security level (must be 1-5)")]
    InvalidQuantumSecurityLevel,

    #[msg("Quantum bearer token has already been redeemed")]
    QuantumTokenAlreadyRedeemed,

    #[msg("Quantum bearer token has expired")]
    QuantumTokenExpired,

    #[msg("Entangled pair is not active")]
    EntanglementNotActive,

    #[msg("Quantum yield vault already collapsed")]
    YieldAlreadyCollapsed,

    #[msg("Metadata name exceeds Metaplex limit of 32 bytes")]
    MetadataNameTooLong,

    #[msg("Metadata symbol exceeds Metaplex limit of 10 bytes")]
    MetadataSymbolTooLong,

    #[msg("Metadata URI exceeds Metaplex limit of 200 bytes")]
    MetadataUriTooLong,

    #[msg("Metadata PDA does not match mint")]
    InvalidMetadataPda,
}
